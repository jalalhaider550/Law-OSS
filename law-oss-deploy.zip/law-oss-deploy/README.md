# Law OSS — Open Source Legal AI

The free, open-source alternative to Harvey AI and Legora.

## Deploy to www.lawoss.com in 5 steps

### Step 1 — GitHub
1. Go to github.com and sign up (free)
2. Click the + icon → New repository
3. Name it `law-oss`, keep it public, click Create
4. Click "uploading an existing file"
5. Drag and drop ALL files from this zip (keep folder structure)
6. Click Commit changes

### Step 2 — Vercel
1. Go to vercel.com and sign up with your GitHub account
2. Click "Add New Project"
3. Select your `law-oss` repository
4. Framework preset: Vite (auto-detected)
5. Click Deploy — done in ~60 seconds

### Step 3 — Connect lawoss.com
1. In your Vercel project, go to Settings → Domains
2. Type `www.lawoss.com` and click Add
3. Vercel shows you DNS records to add
4. Log in to wherever you bought lawoss.com (GoDaddy, Namecheap etc.)
5. Go to DNS settings and add the records Vercel gives you
6. Wait up to 1 hour for DNS to propagate — usually under 10 minutes

## Local development

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Stack

- React 18
- Vite
- Anthropic API (BYOK — user's own key)
- Zero backend — fully client-side
- AGPL-3.0 licensed
