import { useState, useRef, useEffect } from "react";

// ── Theme ─────────────────────────────────────────────────────────────────────
const T = {
  bg: "#ffffff", surface: "#f5f5f5", surface2: "#ebebeb",
  border: "#d9d9d9", border2: "#b8b8b8",
  text: "#0a0a0a", muted: "#555555", dim: "#888888",
  accent: "#0a0a0a", green: "#1a7a3c", red: "#b91c1c",
};

// ── Persist helpers — store user + key in localStorage so never asked again ──
const STORAGE_KEY = "lawoss_user_v1";
const saveUser = (u) => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(u)); } catch {} };
const loadUser = () => { try { const s = localStorage.getItem(STORAGE_KEY); return s ? JSON.parse(s) : null; } catch { return null; } };
const clearUser = () => { try { localStorage.removeItem(STORAGE_KEY); } catch {} };

// ── Data ──────────────────────────────────────────────────────────────────────
const SAMPLE_PROJECTS = [
  { id: 1, name: "Meridian Capital Acquisition", docs: 12, updated: "2h ago", status: "active" },
  { id: 2, name: "NDA Review — TechFlow Inc.", docs: 3, updated: "Yesterday", status: "active" },
  { id: 3, name: "Employment Agreements Q2", docs: 8, updated: "3 days ago", status: "review" },
];

const SAMPLE_WORKFLOWS = [
  { id: 1, name: "Due Diligence Review", steps: ["Upload documents", "Extract key clauses", "Flag risks", "Generate summary"] },
  { id: 2, name: "Contract Comparison", steps: ["Upload base", "Upload comparison", "Identify differences", "Summarize deviations"] },
  { id: 3, name: "Compliance Audit", steps: ["Upload policy docs", "Check regulations", "Generate compliance report"] },
];

const JURISDICTIONS = [
  { label: "🇺🇸 New York", value: "New York, USA", system: "common law", flag: "🇺🇸" },
  { label: "🇺🇸 California", value: "California, USA", system: "common law", flag: "🇺🇸" },
  { label: "🇺🇸 Delaware", value: "Delaware, USA", system: "common law", flag: "🇺🇸" },
  { label: "🇺🇸 Texas", value: "Texas, USA", system: "common law", flag: "🇺🇸" },
  { label: "🇺🇸 Federal (USA)", value: "Federal, USA", system: "common law", flag: "🇺🇸" },
  { label: "🇬🇧 England & Wales", value: "England and Wales, UK", system: "common law", flag: "🇬🇧" },
  { label: "🏴 Scotland", value: "Scotland, UK", system: "mixed", flag: "🏴" },
  { label: "🇦🇪 UAE (DIFC)", value: "Dubai International Financial Centre, UAE", system: "common law", flag: "🇦🇪" },
  { label: "🇸🇬 Singapore", value: "Singapore", system: "common law", flag: "🇸🇬" },
  { label: "🇦🇺 Australia (NSW)", value: "New South Wales, Australia", system: "common law", flag: "🇦🇺" },
  { label: "🇨🇦 Ontario, Canada", value: "Ontario, Canada", system: "common law", flag: "🇨🇦" },
  { label: "🇮🇳 India", value: "India", system: "common law", flag: "🇮🇳" },
  { label: "🇩🇪 Germany", value: "Germany", system: "civil law", flag: "🇩🇪" },
  { label: "🇫🇷 France", value: "France", system: "civil law", flag: "🇫🇷" },
  { label: "🇳🇱 Netherlands", value: "Netherlands", system: "civil law", flag: "🇳🇱" },
];

const CONTRACT_CATEGORIES = [
  { label: "Corporate & M&A", icon: "🏛", types: [
    { id: "spa", label: "Share Purchase Agreement (SPA)", desc: "Full acquisition of company shares" },
    { id: "asset_purchase", label: "Asset Purchase Agreement", desc: "Acquisition of specific business assets" },
    { id: "merger", label: "Merger Agreement", desc: "Business combination agreement" },
    { id: "shareholders", label: "Shareholders Agreement", desc: "Rights and obligations of shareholders" },
    { id: "jv", label: "Joint Venture Agreement", desc: "Co-venture between two entities" },
    { id: "loi", label: "Letter of Intent (LOI)", desc: "Pre-contractual term sheet" },
    { id: "termsheet", label: "Term Sheet", desc: "Investment or deal term sheet" },
  ]},
  { label: "Commercial Contracts", icon: "📋", types: [
    { id: "nda", label: "Non-Disclosure Agreement (NDA)", desc: "Mutual or one-way confidentiality" },
    { id: "service", label: "Master Services Agreement", desc: "Ongoing services framework" },
    { id: "saas", label: "SaaS Subscription Agreement", desc: "Software-as-a-service terms" },
    { id: "consulting", label: "Consulting Agreement", desc: "Independent contractor engagement" },
    { id: "supply", label: "Supply Agreement", desc: "Goods supply and delivery terms" },
    { id: "distribution", label: "Distribution Agreement", desc: "Reseller or distribution rights" },
    { id: "agency", label: "Agency Agreement", desc: "Agent authorized to act on behalf" },
  ]},
  { label: "Employment & HR", icon: "👤", types: [
    { id: "employment", label: "Employment Agreement", desc: "Full-time or part-time employment" },
    { id: "executive", label: "Executive Service Agreement", desc: "C-suite or director-level contract" },
    { id: "ip_assignment", label: "IP Assignment Agreement", desc: "Employee IP and inventions assignment" },
    { id: "non_compete", label: "Non-Compete & Non-Solicit", desc: "Restrictive covenants post-employment" },
    { id: "severance", label: "Severance Agreement", desc: "Termination and separation terms" },
  ]},
  { label: "Real Estate & Leases", icon: "🏢", types: [
    { id: "commercial_lease", label: "Commercial Lease Agreement", desc: "Office, retail, or industrial lease" },
    { id: "residential_lease", label: "Residential Tenancy Agreement", desc: "Residential rental agreement" },
    { id: "sublease", label: "Sublease Agreement", desc: "Tenant to subtenant arrangement" },
    { id: "property_sale", label: "Property Sale Agreement", desc: "Real property purchase and sale" },
  ]},
  { label: "Intellectual Property", icon: "💡", types: [
    { id: "ip_licence", label: "IP Licence Agreement", desc: "Grant of licence over IP rights" },
    { id: "trademark_licence", label: "Trademark Licence", desc: "Brand and trademark licensing" },
    { id: "software_licence", label: "Software Licence Agreement", desc: "Proprietary software licensing" },
    { id: "co_dev", label: "Co-Development Agreement", desc: "Joint IP development and ownership" },
  ]},
  { label: "Finance & Investment", icon: "💰", types: [
    { id: "safe", label: "SAFE Note", desc: "Simple Agreement for Future Equity" },
    { id: "convertible_note", label: "Convertible Note", desc: "Debt convertible to equity" },
    { id: "loan", label: "Loan Agreement", desc: "Commercial lending agreement" },
    { id: "guarantee", label: "Guarantee & Indemnity", desc: "Third-party guarantee of obligations" },
  ]},
];

// ── Shared UI ─────────────────────────────────────────────────────────────────
const Dots = () => (
  <div style={{ display: "flex", gap: 5, alignItems: "center" }}>
    {[0,1,2].map(i => (
      <div key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: T.accent, animation: `lp 1.1s ease-in-out ${i*0.18}s infinite` }} />
    ))}
  </div>
);

const Inp = ({ style, ...props }) => (
  <input {...props} style={{
    width: "100%", padding: "10px 13px", background: T.bg, border: `1.5px solid ${T.border}`,
    borderRadius: 8, color: T.text, fontSize: 13.5, outline: "none", fontFamily: "inherit",
    boxSizing: "border-box", transition: "border-color 0.15s", ...style,
  }}
    onFocus={e => e.target.style.borderColor = T.accent}
    onBlur={e => e.target.style.borderColor = T.border}
  />
);

const Btn = ({ children, variant = "primary", style, disabled, onClick, ...rest }) => (
  <button onClick={onClick} disabled={disabled} {...rest} style={{
    padding: "10px 22px", border: "none", borderRadius: 8, cursor: disabled ? "not-allowed" : "pointer",
    fontSize: 13.5, fontWeight: 600, fontFamily: "inherit", transition: "all 0.15s",
    opacity: disabled ? 0.4 : 1,
    ...(variant === "primary"
      ? { background: T.accent, color: "#fff" }
      : { background: T.surface2, color: T.text, border: `1.5px solid ${T.border}` }),
    ...style,
  }}
    onMouseEnter={e => { if (!disabled) { e.currentTarget.style.opacity = "0.88"; e.currentTarget.style.transform = "translateY(-1px)"; }}}
    onMouseLeave={e => { e.currentTarget.style.opacity = disabled ? "0.4" : "1"; e.currentTarget.style.transform = "translateY(0)"; }}
  >{children}</button>
);

// ── BYOK API call — sends user's own key, never touches Law OSS tokens ────────
const anthropicFetch = async (apiKey, system, messages) => {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1000, system, messages }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message || "API error");
  return data.content?.map(c => c.text || "").join("") || "";
};

// ── Auth page (Signup → API Key, or Login → API Key) ─────────────────────────
const TESTIMONIALS_AUTH = [
  { quote: "I replaced Harvey the same afternoon. Full feature parity, zero licensing fee.", name: "James Kowalski", role: "Partner, Kowalski & Reid LLP" },
  { quote: "We were paying $38K/year for Legora. Law OSS does the same work for the cost of our API calls.", name: "Priya Nair", role: "General Counsel, Elevate Fintech" },
  { quote: "Contract generation used to take my paralegal a full day. Now it's four minutes.", name: "David Chen", role: "Solo Practitioner, NYC" },
  { quote: "Open source means I actually trust what it's doing with my client documents.", name: "Sarah Okafor", role: "Senior Associate, Morrison & Blake" },
];

function AuthPage({ onAuth }) {
  const [mode, setMode] = useState("signup"); // "signup" | "login" | "apikey"
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [pendingUser, setPendingUser] = useState(null);

  const lbl = { fontSize: 11.5, fontWeight: 600, color: T.muted, display: "block", marginBottom: 5, letterSpacing: "0.04em", textTransform: "uppercase" };

  const handleSignup = () => {
    if (!name.trim() || !email.trim() || !password.trim()) { setError("Please fill in all fields."); return; }
    if (!email.includes("@")) { setError("Please enter a valid email."); return; }
    if (password.length < 6) { setError("Password must be at least 6 characters."); return; }
    setError(""); setPendingUser({ name: name.trim(), email: email.trim() }); setMode("apikey");
  };

  const handleLogin = () => {
    if (!email.trim() || !password.trim()) { setError("Please fill in all fields."); return; }
    setError(""); setPendingUser({ name: email.split("@")[0], email: email.trim() }); setMode("apikey");
  };

  const handleApiKey = () => {
    if (!apiKey.trim()) { setError("Please enter your Anthropic API key."); return; }
    // No format check — Anthropic key formats vary. A wrong key will show
    // a clear error on the first real call inside the app.
    const user = { ...pendingUser, apiKey: apiKey.trim() };
    saveUser(user);
    onAuth(user);
  };

  const leftPanel = (
    <div style={{ width: "44%", background: "#0a0a0a", padding: "48px 44px", display: "flex", flexDirection: "column", position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: -80, right: -80, width: 320, height: 320, borderRadius: "50%", border: "1px solid rgba(255,255,255,0.05)" }} />
      <div style={{ position: "absolute", bottom: 60, left: -100, width: 400, height: 400, borderRadius: "50%", border: "1px solid rgba(255,255,255,0.04)" }} />

      <div style={{ display: "flex", alignItems: "center", gap: 11, marginBottom: 52, position: "relative" }}>
        <div style={{ width: 36, height: 36, background: "rgba(255,255,255,0.1)", borderRadius: 9, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17, border: "1px solid rgba(255,255,255,0.15)" }}>⚖</div>
        <div>
          <div style={{ fontSize: 15, fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}>Law OSS</div>
          <div style={{ fontSize: 9.5, color: "rgba(255,255,255,0.4)", letterSpacing: "0.12em", textTransform: "uppercase" }}>Open Legal AI</div>
        </div>
      </div>

      <div style={{ position: "relative", flex: 1 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", letterSpacing: "0.14em", textTransform: "uppercase", marginBottom: 14 }}>The open source alternative to</div>
        <div style={{ display: "flex", gap: 8, marginBottom: 30, flexWrap: "wrap" }}>
          {["Harvey AI", "Legora", "CoCounsel", "Clio"].map(n => (
            <span key={n} style={{ padding: "4px 12px", background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 20, fontSize: 12, color: "rgba(255,255,255,0.7)", fontWeight: 500 }}>{n}</span>
          ))}
        </div>
        <h2 style={{ fontSize: 30, fontWeight: 800, color: "#fff", margin: "0 0 14px", lineHeight: 1.2, letterSpacing: "-0.03em" }}>Full feature parity.<br />Zero licensing cost.</h2>
        <p style={{ fontSize: 13.5, color: "rgba(255,255,255,0.5)", lineHeight: 1.7, margin: "0 0 36px", maxWidth: 320 }}>Connect your own Anthropic API key. Your documents never leave your control. Attorney-client privilege preserved.</p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 18, marginBottom: 36 }}>
          {[["30+", "Contract types"], ["15", "Jurisdictions"], ["$0", "Platform fees"]].map(([val, lbl]) => (
            <div key={lbl}>
              <div style={{ fontSize: 22, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em" }}>{val}</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.38)", marginTop: 2 }}>{lbl}</div>
            </div>
          ))}
        </div>

        <div style={{ display: "grid", gap: 12 }}>
          {TESTIMONIALS_AUTH.slice(0, 2).map((t, i) => (
            <div key={i} style={{ padding: "14px 16px", background: "rgba(255,255,255,0.05)", borderRadius: 11, border: "1px solid rgba(255,255,255,0.08)" }}>
              <p style={{ fontSize: 12.5, color: "rgba(255,255,255,0.65)", margin: "0 0 8px", lineHeight: 1.55, fontStyle: "italic" }}>"{t.quote}"</p>
              <div style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.4)" }}>{t.name} · <span style={{ fontWeight: 400 }}>{t.role}</span></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: T.surface, display: "flex", fontFamily: "'DM Sans', system-ui, sans-serif" }}>
      {leftPanel}
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", padding: "48px 56px" }}>
        <div style={{ width: "100%", maxWidth: 390 }}>

          {/* ── API Key step ── */}
          {mode === "apikey" ? (<>
            <div style={{ width: 46, height: 46, background: T.surface, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, marginBottom: 18, border: `1.5px solid ${T.border}` }}>🔑</div>
            <h1 style={{ fontSize: 24, fontWeight: 800, color: T.text, margin: "0 0 6px", letterSpacing: "-0.03em" }}>Connect your API key</h1>
            <p style={{ fontSize: 13.5, color: T.muted, margin: "0 0 22px", lineHeight: 1.6 }}>Law OSS uses your own Anthropic key. Your tokens, your data — we never see them.</p>

            <div style={{ background: "#f0fdf4", border: "1.5px solid #bbf7d0", borderRadius: 10, padding: "12px 15px", marginBottom: 20, fontSize: 12.5, color: T.green, display: "flex", gap: 9, alignItems: "flex-start" }}>
              <span style={{ marginTop: 1 }}>✓</span>
              <span>Your key is saved in your browser and <strong>never asked again</strong>. All calls go directly from your browser to Anthropic.</span>
            </div>

            <div style={{ marginBottom: 18 }}>
              <label style={lbl}>Anthropic API Key</label>
              <div style={{ position: "relative" }}>
                <Inp type={showKey ? "text" : "password"} value={apiKey} onChange={e => setApiKey(e.target.value)} placeholder="Paste your Anthropic API key here" style={{ paddingRight: 50 }} />
                <button onClick={() => setShowKey(v => !v)} style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: T.muted, fontSize: 12.5 }}>{showKey ? "Hide" : "Show"}</button>
              </div>
              <div style={{ fontSize: 11.5, color: T.dim, marginTop: 6 }}>Get yours at <a href="https://console.anthropic.com" target="_blank" rel="noreferrer" style={{ color: T.accent }}>console.anthropic.com</a> — never shared.</div>
            </div>

            {error && <div style={{ padding: "10px 13px", background: "#fef2f2", border: "1.5px solid #fecaca", borderRadius: 8, fontSize: 12.5, color: T.red, marginBottom: 14 }}>{error}</div>}

            <Btn onClick={handleApiKey} disabled={!apiKey.trim()} style={{ width: "100%", padding: "12px", fontSize: 14 }}>
              Enter Law OSS →
            </Btn>
            <button onClick={() => setMode("signup")} style={{ background: "none", border: "none", cursor: "pointer", color: T.muted, fontSize: 12.5, marginTop: 14, display: "block", textAlign: "center", width: "100%", fontFamily: "inherit" }}>← Back</button>
          </>) :

          /* ── Signup step ── */
          mode === "signup" ? (<>
            <h1 style={{ fontSize: 24, fontWeight: 800, color: T.text, margin: "0 0 6px", letterSpacing: "-0.03em" }}>Create your account</h1>
            <p style={{ fontSize: 13.5, color: T.muted, margin: "0 0 24px" }}>Free forever. Open source. No credit card.</p>

            <div style={{ display: "grid", gap: 14, marginBottom: 18 }}>
              <div><label style={lbl}>Full Name</label><Inp value={name} onChange={e => setName(e.target.value)} placeholder="Jane Smith" /></div>
              <div><label style={lbl}>Email Address</label><Inp type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="jane@lawfirm.com" /></div>
              <div><label style={lbl}>Password</label><Inp type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Min. 6 characters" /></div>
            </div>

            {error && <div style={{ padding: "10px 13px", background: "#fef2f2", border: "1.5px solid #fecaca", borderRadius: 8, fontSize: 12.5, color: T.red, marginBottom: 14 }}>{error}</div>}

            <Btn onClick={handleSignup} style={{ width: "100%", padding: "12px", fontSize: 14, marginBottom: 14 }}>Create Account →</Btn>

            <div style={{ position: "relative", textAlign: "center", margin: "4px 0 14px" }}>
              <div style={{ position: "absolute", top: "50%", left: 0, right: 0, height: 1, background: T.border }} />
              <span style={{ position: "relative", background: T.surface, padding: "0 12px", fontSize: 12, color: T.dim }}>or</span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 22 }}>
              {[["🔵", "Google"], ["⚫", "GitHub"]].map(([ico, label]) => (
                <button key={label} style={{ padding: "9px", background: T.bg, border: `1.5px solid ${T.border}`, borderRadius: 8, cursor: "pointer", fontSize: 13, fontWeight: 500, color: T.text, fontFamily: "inherit", display: "flex", alignItems: "center", justifyContent: "center", gap: 7 }}
                  onMouseEnter={e => e.currentTarget.style.borderColor = T.accent}
                  onMouseLeave={e => e.currentTarget.style.borderColor = T.border}>
                  {ico} {label}
                </button>
              ))}
            </div>

            <div style={{ textAlign: "center", fontSize: 13, color: T.muted }}>
              Already have an account?{" "}
              <button onClick={() => { setMode("login"); setError(""); }} style={{ background: "none", border: "none", cursor: "pointer", color: T.text, fontWeight: 700, fontSize: 13, fontFamily: "inherit", textDecoration: "underline" }}>Sign in</button>
            </div>
          </>) :

          /* ── Login step ── */
          (<>
            <h1 style={{ fontSize: 24, fontWeight: 800, color: T.text, margin: "0 0 6px", letterSpacing: "-0.03em" }}>Welcome back</h1>
            <p style={{ fontSize: 13.5, color: T.muted, margin: "0 0 24px" }}>Sign in to your Law OSS workspace.</p>

            <div style={{ display: "grid", gap: 14, marginBottom: 18 }}>
              <div><label style={lbl}>Email Address</label><Inp type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="jane@lawfirm.com" /></div>
              <div><label style={lbl}>Password</label><Inp type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Your password" /></div>
            </div>

            {error && <div style={{ padding: "10px 13px", background: "#fef2f2", border: "1.5px solid #fecaca", borderRadius: 8, fontSize: 12.5, color: T.red, marginBottom: 14 }}>{error}</div>}

            <Btn onClick={handleLogin} style={{ width: "100%", padding: "12px", fontSize: 14, marginBottom: 20 }}>Sign In →</Btn>

            <div style={{ textAlign: "center", fontSize: 13, color: T.muted }}>
              No account?{" "}
              <button onClick={() => { setMode("signup"); setError(""); }} style={{ background: "none", border: "none", cursor: "pointer", color: T.text, fontWeight: 700, fontSize: 13, fontFamily: "inherit", textDecoration: "underline" }}>Sign up free</button>
            </div>
          </>)}
        </div>
      </div>
    </div>
  );
}

// ── Sidebar ───────────────────────────────────────────────────────────────────
function Sidebar({ view, setView, setProject, user, onSignOut }) {
  const nav = [
    { id: "projects", label: "Projects", icon: "▤" },
    { id: "chat", label: "Document Chat", icon: "◎" },
    { id: "contracts", label: "Contract Studio", icon: "⟐" },
    { id: "workflows", label: "Workflows", icon: "⌬" },
  ];
  return (
    <aside style={{ width: 232, background: T.surface, borderRight: `1.5px solid ${T.border}`, display: "flex", flexDirection: "column", flexShrink: 0, height: "100vh", position: "sticky", top: 0 }}>
      <div style={{ padding: "20px 18px 16px", borderBottom: `1.5px solid ${T.border}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 32, height: 32, background: T.accent, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, color: "#fff" }}>⚖</div>
          <div>
            <div style={{ fontSize: 13.5, fontWeight: 800, color: T.text, letterSpacing: "-0.02em" }}>Law OSS</div>
            <div style={{ fontSize: 9.5, color: T.dim, letterSpacing: "0.1em", textTransform: "uppercase", marginTop: 1 }}>Open Legal AI</div>
          </div>
        </div>
      </div>
      <div style={{ padding: "12px 10px 6px" }}>
        <div style={{ fontSize: 9.5, color: T.dim, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 5, paddingLeft: 8 }}>Workspace</div>
        {nav.map(item => (
          <button key={item.id} onClick={() => setView(item.id)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 9, padding: "8px 10px", borderRadius: 7, border: "none", cursor: "pointer", background: view === item.id ? T.border : "transparent", color: view === item.id ? T.text : T.muted, fontSize: 13, fontWeight: view === item.id ? 600 : 400, textAlign: "left", marginBottom: 1, transition: "all 0.12s", fontFamily: "inherit" }}>
            <span style={{ fontSize: 13, opacity: view === item.id ? 1 : 0.55 }}>{item.icon}</span>
            {item.label}
          </button>
        ))}
      </div>
      <div style={{ padding: "6px 10px", marginTop: 6 }}>
        <div style={{ fontSize: 9.5, color: T.dim, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 5, paddingLeft: 8 }}>Recent</div>
        {SAMPLE_PROJECTS.map(p => (
          <button key={p.id} onClick={() => { setProject(p); setView("chat"); }} style={{ width: "100%", padding: "6px 10px", borderRadius: 6, border: "none", background: "transparent", cursor: "pointer", textAlign: "left", marginBottom: 1, fontFamily: "inherit" }}>
            <div style={{ fontSize: 11.5, color: T.muted, fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.name}</div>
            <div style={{ fontSize: 10.5, color: T.dim, marginTop: 1 }}>{p.updated}</div>
          </button>
        ))}
      </div>
      <div style={{ marginTop: "auto", padding: "12px 18px", borderTop: `1.5px solid ${T.border}` }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 600, color: T.text }}>{user?.name || "User"}</div>
            <div style={{ fontSize: 10.5, color: T.dim }}>API key connected ✓</div>
          </div>
          <button onClick={onSignOut} style={{ background: "none", border: `1.5px solid ${T.border}`, borderRadius: 6, padding: "4px 9px", cursor: "pointer", fontSize: 11, color: T.muted, fontFamily: "inherit" }}>Out</button>
        </div>
      </div>
    </aside>
  );
}

// ── Projects ──────────────────────────────────────────────────────────────────
function ProjectsView({ setView, setProject }) {
  return (
    <div style={{ padding: "40px 48px", maxWidth: 860 }}>
      <h1 style={{ fontSize: 26, fontWeight: 800, color: T.text, margin: "0 0 6px", letterSpacing: "-0.03em" }}>Projects</h1>
      <p style={{ color: T.muted, fontSize: 13.5, margin: "0 0 24px" }}>Organize documents and analysis by matter</p>
      <Btn style={{ marginBottom: 22 }}>+ New Project</Btn>
      <div style={{ display: "grid", gap: 10 }}>
        {SAMPLE_PROJECTS.map(p => (
          <div key={p.id} onClick={() => { setProject(p); setView("chat"); }} style={{ background: T.bg, border: `1.5px solid ${T.border}`, borderRadius: 12, padding: "18px 22px", cursor: "pointer", display: "flex", alignItems: "center", gap: 18, transition: "all 0.15s" }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = T.accent; e.currentTarget.style.background = T.surface; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = T.border; e.currentTarget.style.background = T.bg; }}>
            <div style={{ width: 42, height: 42, background: T.surface2, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17, flexShrink: 0 }}>▤</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: T.text, marginBottom: 3 }}>{p.name}</div>
              <div style={{ fontSize: 12, color: T.muted }}>{p.docs} documents · Updated {p.updated}</div>
            </div>
            <div style={{ padding: "3px 10px", borderRadius: 20, background: p.status === "active" ? "#dcfce7" : "#fef9c3", color: p.status === "active" ? T.green : "#854d0e", fontSize: 10.5, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em" }}>{p.status}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Chat ──────────────────────────────────────────────────────────────────────
function ChatView({ project, apiKey }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [docText, setDocText] = useState("");       // pasted contract text
  const [docName, setDocName] = useState("");
  const [showPaste, setShowPaste] = useState(false); // paste panel open
  const [pasteInput, setPasteInput] = useState("");
  const bottomRef = useRef(null);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const loadDoc = () => {
    if (!pasteInput.trim()) return;
    setDocText(pasteInput.trim());
    setDocName("Pasted document");
    setPasteInput("");
    setShowPaste(false);
    setMessages([{ role: "assistant", text: "Document loaded. I have read all the text. Ask me anything — flag risky clauses, summarise obligations, extract defined terms, or any other analysis." }]);
  };

  const send = async () => {
    if (!input.trim()) return;
    setMessages(prev => [...prev, { role: "user", text: input }]);
    const q = input; setInput(""); setLoading(true);

    const system = docText
      ? `You are a senior legal AI assistant inside Law OSS, an open-source legal platform for solo and small-firm lawyers.

The user has provided the following contract text. Use it as your sole source of truth. Always cite specific clause numbers or section headings. When flagging risky clauses, list each one with its reference and explain the risk concisely.

CONTRACT TEXT:
---
${docText.slice(0, 14000)}
---`
      : "You are a senior legal AI assistant inside Law OSS. Help lawyers with contract analysis, clause drafting, risk identification, and legal questions. Be structured, precise, and actionable.";

    const history = messages.map(m => ({ role: m.role, content: m.text || "Continue." }));

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
        body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1000, system, messages: [...history, { role: "user", content: q }] }),
      });
      if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t.slice(0,200)}`); }
      const data = await res.json();
      if (data.error) throw new Error(data.error.message || JSON.stringify(data.error));
      setMessages(prev => [...prev, { role: "assistant", text: data.content?.map(c => c.text||"").join("") || "No response." }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: "assistant", text: `Error: ${e.message}` }]);
    }
    setLoading(false);
  };

  const chips = ["Flag risky clauses", "Summarise key obligations", "Extract defined terms", "Identify liability caps", "Find termination rights", "Who are the parties?"];

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", maxWidth: 820, width: "100%" }}>
      <div style={{ padding: "20px 40px 16px", borderBottom: `1.5px solid ${T.border}`, flexShrink: 0 }}>
        <div style={{ fontSize: 10.5, color: T.muted, textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 3 }}>Document Chat</div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <h2 style={{ margin: 0, fontSize: 18, color: T.text, fontWeight: 700, letterSpacing: "-0.02em" }}>{project ? project.name : "General Legal Analysis"}</h2>
          <button onClick={() => setShowPaste(!showPaste)} style={{ padding: "6px 14px", background: docText ? T.accent : T.surface, border: `1.5px solid ${docText ? T.accent : T.border}`, borderRadius: 8, cursor: "pointer", fontSize: 12, fontWeight: 600, color: docText ? "#fff" : T.muted, fontFamily: "inherit" }}>
            {docText ? "📄 Doc loaded" : "+ Paste contract"}
          </button>
        </div>
      </div>

      {/* Paste panel */}
      {showPaste && (
        <div style={{ padding: "16px 40px", borderBottom: `1.5px solid ${T.border}`, background: "#fffbeb", flexShrink: 0 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: "#92400e", marginBottom: 6 }}>Paste your contract text below</div>
          <div style={{ fontSize: 11.5, color: "#b45309", marginBottom: 10 }}>Open your PDF, select all text (Ctrl+A / Cmd+A), copy, then paste here. Works with any contract.</div>
          <textarea value={pasteInput} onChange={e => setPasteInput(e.target.value)}
            placeholder="Paste full contract text here..."
            style={{ width: "100%", height: 140, padding: "10px 13px", border: `1.5px solid #fbbf24`, borderRadius: 9, fontSize: 13, color: T.text, resize: "vertical", outline: "none", fontFamily: "inherit", boxSizing: "border-box", background: "#fff" }}
          />
          <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
            <button onClick={loadDoc} disabled={!pasteInput.trim()} style={{ padding: "8px 18px", background: T.accent, border: "none", borderRadius: 7, cursor: "pointer", fontSize: 13, fontWeight: 600, color: "#fff", opacity: !pasteInput.trim() ? 0.4 : 1 }}>Load document →</button>
            <button onClick={() => { setShowPaste(false); setPasteInput(""); }} style={{ padding: "8px 14px", background: "transparent", border: `1.5px solid ${T.border}`, borderRadius: 7, cursor: "pointer", fontSize: 13, color: T.muted, fontFamily: "inherit" }}>Cancel</button>
            {docText && <button onClick={() => { setDocText(""); setDocName(""); setMessages([]); setShowPaste(false); }} style={{ padding: "8px 14px", background: "transparent", border: `1.5px solid #fca5a5`, borderRadius: 7, cursor: "pointer", fontSize: 13, color: "#dc2626", fontFamily: "inherit" }}>Clear document</button>}
          </div>
        </div>
      )}

      <div style={{ flex: 1, overflowY: "auto", padding: "20px 40px" }}>
        {messages.length === 0 && (
          <div style={{ textAlign: "center", marginTop: 48 }}>
            <div style={{ fontSize: 36, marginBottom: 12, opacity: 0.15 }}>◎</div>
            <div style={{ fontSize: 15, color: T.muted, marginBottom: 4 }}>Analyse any legal document</div>
            <div style={{ fontSize: 13, color: T.dim, marginBottom: 6 }}>Click <strong style={{ color: T.text }}>+ Paste contract</strong> above to load your document</div>
            <div style={{ fontSize: 12, color: T.dim, marginBottom: 20 }}>Open your PDF → select all → copy → paste into the panel</div>
            <div style={{ display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap" }}>
              {chips.map(s => (
                <button key={s} onClick={() => setInput(s)} style={{ padding: "6px 13px", background: T.surface, border: `1.5px solid ${T.border}`, borderRadius: 20, cursor: "pointer", color: T.muted, fontSize: 12, fontFamily: "inherit", transition: "all 0.15s" }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = T.accent; e.currentTarget.style.color = T.text; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = T.border; e.currentTarget.style.color = T.muted; }}>{s}</button>
              ))}
            </div>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} style={{ marginBottom: 16, display: "flex", gap: 11, flexDirection: m.role === "user" ? "row-reverse" : "row" }}>
            <div style={{ width: 28, height: 28, borderRadius: 7, flexShrink: 0, background: m.role === "user" ? T.accent : T.surface2, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10.5, fontWeight: 700, color: m.role === "user" ? "#fff" : T.muted }}>
              {m.role === "user" ? "U" : "AI"}
            </div>
            <div style={{ maxWidth: "80%", padding: "10px 14px", borderRadius: 11, background: m.role === "user" ? T.accent : T.surface, border: m.role === "user" ? "none" : `1.5px solid ${T.border}`, color: m.role === "user" ? "#fff" : T.text, fontSize: 13.5, lineHeight: 1.7, whiteSpace: "pre-wrap" }}>
              {m.text}
            </div>
          </div>
        ))}
        {loading && (
          <div style={{ display: "flex", gap: 11, marginBottom: 16 }}>
            <div style={{ width: 28, height: 28, borderRadius: 7, background: T.surface2, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10.5, fontWeight: 700, color: T.muted }}>AI</div>
            <div style={{ padding: "10px 14px", background: T.surface, border: `1.5px solid ${T.border}`, borderRadius: 11 }}><Dots /></div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div style={{ padding: "12px 40px 20px", borderTop: `1.5px solid ${T.border}`, flexShrink: 0 }}>
        {docText && (
          <div style={{ marginBottom: 8, padding: "4px 11px", background: "#eff6ff", border: "1.5px solid #bfdbfe", borderRadius: 6, fontSize: 11.5, color: "#1d4ed8", display: "inline-flex", alignItems: "center", gap: 7 }}>
            📄 {docName} — ask anything about it
          </div>
        )}
        <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
          <textarea value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder={docText ? "Ask about the document... e.g. flag risky clauses" : "Paste your contract first, then ask questions here..."}
            style={{ flex: 1, padding: "9px 13px", background: T.surface, border: `1.5px solid ${T.border}`, borderRadius: 9, color: T.text, fontSize: 13.5, resize: "none", outline: "none", fontFamily: "inherit", minHeight: 40, maxHeight: 110, transition: "border-color 0.15s" }}
            onFocus={e => e.target.style.borderColor = T.accent}
            onBlur={e => e.target.style.borderColor = T.border}
            rows={1} />
          <button onClick={send} disabled={loading || !input.trim()} style={{ padding: "9px 16px", background: T.accent, border: "none", borderRadius: 9, cursor: "pointer", color: "#fff", fontSize: 14, fontWeight: 700, flexShrink: 0, opacity: (loading || !input.trim()) ? 0.45 : 1, fontFamily: "inherit" }}>→</button>
        </div>
      </div>
    </div>
  );
}

// ── Contracts ─────────────────────────────────────────────────────────────────
function ContractsView({ apiKey }) {
  const [selectedCat, setSelectedCat] = useState(null);
  const [selectedType, setSelectedType] = useState(null);
  const [jurisdiction, setJurisdiction] = useState(JURISDICTIONS[0]);
  const [party1, setParty1] = useState(""); const [party2, setParty2] = useState("");
  const [party1Type, setParty1Type] = useState("Company"); const [party2Type, setParty2Type] = useState("Company");
  const [notes, setNotes] = useState("");
  const [output, setOutput] = useState(""); const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [step, setStep] = useState("browse");

  const is = { width: "100%", padding: "9px 12px", background: T.bg, border: `1.5px solid ${T.border}`, borderRadius: 8, color: T.text, fontSize: 13, outline: "none", boxSizing: "border-box", fontFamily: "inherit" };
  const lbl = { fontSize: 10.5, color: T.muted, display: "block", marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.07em", fontWeight: 600 };

  const generate = async () => {
    if (!selectedType || !party1 || !party2) return;
    setLoading(true); setOutput(""); setStep("output");
    const jCtx = jurisdiction.system === "civil law" ? "Civil law jurisdiction. Use civil code conventions and statutory references. Avoid common law constructs."
      : jurisdiction.value.includes("Scotland") ? "Scottish mixed legal system. Use Scots law terminology (missives, obligations, etc.) and relevant Scottish statutes."
      : "Common law jurisdiction. Use standard common law drafting conventions.";
    try {
      const text = await anthropicFetch(
        apiKey,
        `You are a senior commercial lawyer specialising in ${jurisdiction.value} law. ${jCtx} Draft professional, numbered, jurisdiction-specific contracts with all essential clauses and a complete execution block appropriate for ${jurisdiction.value}.`,
        [{ role: "user", content: `Draft a ${selectedType.label} under ${jurisdiction.value} law.\nParty A: ${party1} (${party1Type})\nParty B: ${party2} (${party2Type})\n${notes ? `Specific instructions: ${notes}` : ""}\nInclude all standard provisions and a full signature block.` }]
      );
      setOutput(text);
    } catch (e) { setOutput(`Error: ${e.message}`); }
    setLoading(false);
  };

  return (
    <div style={{ padding: "40px 48px", maxWidth: 960, width: "100%" }}>
      <div style={{ marginBottom: 24 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 6 }}>
          <h1 style={{ fontSize: 26, fontWeight: 800, color: T.text, margin: 0, letterSpacing: "-0.03em" }}>Contract Studio</h1>
          {step !== "browse" && <button onClick={() => { setStep("browse"); setOutput(""); }} style={{ padding: "4px 12px", background: T.surface, border: `1.5px solid ${T.border}`, borderRadius: 6, cursor: "pointer", color: T.muted, fontSize: 12, fontFamily: "inherit" }}>← Templates</button>}
        </div>
        <p style={{ color: T.muted, fontSize: 13, margin: 0 }}>30+ contract types · 15 jurisdictions · jurisdiction-aware drafting</p>
      </div>

      {step === "browse" && (
        <div style={{ display: "grid", gap: 24 }}>
          {CONTRACT_CATEGORIES.map(cat => (
            <div key={cat.label}>
              <div style={{ fontSize: 11, color: T.muted, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 10, display: "flex", alignItems: "center", gap: 7 }}>{cat.icon} {cat.label}</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 8 }}>
                {cat.types.map(type => (
                  <button key={type.id} onClick={() => { setSelectedCat(cat); setSelectedType(type); setStep("configure"); setOutput(""); }}
                    style={{ padding: "13px 15px", background: T.bg, border: `1.5px solid ${T.border}`, borderRadius: 10, cursor: "pointer", textAlign: "left", transition: "all 0.15s", fontFamily: "inherit" }}
                    onMouseEnter={e => { e.currentTarget.style.borderColor = T.accent; e.currentTarget.style.background = T.surface; }}
                    onMouseLeave={e => { e.currentTarget.style.borderColor = T.border; e.currentTarget.style.background = T.bg; }}>
                    <div style={{ fontSize: 12.5, fontWeight: 600, color: T.text, marginBottom: 3 }}>{type.label}</div>
                    <div style={{ fontSize: 11.5, color: T.muted }}>{type.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {step === "configure" && (
        <div style={{ background: T.surface, border: `1.5px solid ${T.border}`, borderRadius: 14, padding: 28 }}>
          <div style={{ fontSize: 11.5, color: T.accent, fontWeight: 700, marginBottom: 22, textTransform: "uppercase", letterSpacing: "0.06em" }}>{selectedCat?.icon} {selectedCat?.label} · {selectedType?.label}</div>
          <div style={{ marginBottom: 18 }}>
            <label style={lbl}>Governing Jurisdiction</label>
            <select value={jurisdiction.value} onChange={e => setJurisdiction(JURISDICTIONS.find(j => j.value === e.target.value))} style={is}>
              {JURISDICTIONS.map(j => <option key={j.value} value={j.value}>{j.label} ({j.system})</option>)}
            </select>
            <div style={{ fontSize: 11, color: T.dim, marginTop: 5 }}>Legal system: {jurisdiction.system} · Applies {jurisdiction.value} conventions</div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 150px 1fr 150px", gap: 12, marginBottom: 18 }}>
            <div><label style={lbl}>Party A — Name</label><input value={party1} onChange={e => setParty1(e.target.value)} placeholder="e.g. Meridian Capital Ltd" style={is} /></div>
            <div><label style={lbl}>Type</label><select value={party1Type} onChange={e => setParty1Type(e.target.value)} style={is}>{["Company","Individual","LLP","Partnership","Trust","Government Body"].map(t => <option key={t}>{t}</option>)}</select></div>
            <div><label style={lbl}>Party B — Name</label><input value={party2} onChange={e => setParty2(e.target.value)} placeholder="e.g. TechFlow Inc." style={is} /></div>
            <div><label style={lbl}>Type</label><select value={party2Type} onChange={e => setParty2Type(e.target.value)} style={is}>{["Company","Individual","LLP","Partnership","Trust","Government Body"].map(t => <option key={t}>{t}</option>)}</select></div>
          </div>
          <div style={{ marginBottom: 22 }}>
            <label style={lbl}>Additional Instructions (optional)</label>
            <textarea value={notes} onChange={e => setNotes(e.target.value)}
              placeholder={selectedType?.id === "spa" ? "e.g. Purchase price £5M, locked box, W&I insurance..." : selectedType?.id === "safe" ? "e.g. $500K investment, $5M cap, 20% discount, MFN..." : "e.g. key deal terms, duration, financial terms, special provisions..."}
              rows={3} style={{ ...is, resize: "vertical" }} />
          </div>
          <Btn onClick={generate} disabled={!party1 || !party2}>Generate {jurisdiction.flag} {selectedType?.label}</Btn>
        </div>
      )}

      {step === "output" && (
        loading ? (
          <div style={{ background: T.surface, border: `1.5px solid ${T.border}`, borderRadius: 14, padding: 48, textAlign: "center" }}>
            <div style={{ fontSize: 14, color: T.muted, marginBottom: 5 }}>Drafting your {selectedType?.label}</div>
            <div style={{ fontSize: 12, color: T.dim, marginBottom: 16 }}>Applying {jurisdiction.value} conventions...</div>
            <div style={{ display: "flex", justifyContent: "center" }}><Dots /></div>
          </div>
        ) : output && (
          <div style={{ background: T.surface, border: `1.5px solid ${T.border}`, borderRadius: 14, padding: 26 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 10 }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: T.text, marginBottom: 2 }}>{selectedType?.label}</div>
                <div style={{ fontSize: 11, color: T.muted }}>{jurisdiction.flag} {jurisdiction.value} · {party1} / {party2}</div>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <Btn variant="ghost" onClick={() => setStep("configure")} style={{ padding: "6px 12px", fontSize: 12, background: T.bg, border: `1.5px solid ${T.border}` }}>Edit</Btn>
                <Btn variant="ghost" onClick={() => { navigator.clipboard.writeText(output); setCopied(true); setTimeout(() => setCopied(false), 2000); }} style={{ padding: "6px 12px", fontSize: 12, background: copied ? "#dcfce7" : T.bg, border: `1.5px solid ${copied ? "#86efac" : T.border}`, color: copied ? T.green : T.muted }}>{copied ? "Copied ✓" : "Copy"}</Btn>
              </div>
            </div>
            <div style={{ background: T.bg, borderRadius: 10, padding: "20px 24px", border: `1.5px solid ${T.border}`, maxHeight: 560, overflowY: "auto" }}>
              <pre style={{ color: T.text, fontSize: 12.5, lineHeight: 1.85, whiteSpace: "pre-wrap", fontFamily: "'Courier New', monospace", margin: 0 }}>{output}</pre>
            </div>
          </div>
        )
      )}
    </div>
  );
}

// ── Workflows ─────────────────────────────────────────────────────────────────
function WorkflowsView({ apiKey }) {
  const [active, setActive] = useState(null);
  const [stepIdx, setStepIdx] = useState(0);
  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);

  const run = async (w) => {
    setActive(w); setStepIdx(0); setOutput(""); setLoading(true);
    for (let i = 0; i < w.steps.length; i++) { setStepIdx(i); await new Promise(r => setTimeout(r, 750)); }
    try {
      const text = await anthropicFetch(
        apiKey,
        "You are a legal AI assistant in Law OSS. Simulate completing a legal workflow and provide a detailed, structured output report with findings, key points, risks, and recommendations.",
        [{ role: "user", content: `Completed the "${w.name}" workflow. Provide a detailed structured output report as if you processed real legal documents. Format clearly with sections.` }]
      );
      setOutput(text);
    } catch (e) { setOutput(`Error: ${e.message}`); }
    setLoading(false);
  };

  return (
    <div style={{ padding: "40px 48px", maxWidth: 860 }}>
      <h1 style={{ fontSize: 26, fontWeight: 800, color: T.text, margin: "0 0 6px", letterSpacing: "-0.03em" }}>Workflows</h1>
      <p style={{ color: T.muted, fontSize: 13.5, margin: "0 0 24px" }}>Multi-step legal automation pipelines</p>
      <div style={{ display: "grid", gap: 12, marginBottom: 24 }}>
        {SAMPLE_WORKFLOWS.map(w => (
          <div key={w.id} style={{ background: T.bg, border: `1.5px solid ${active?.id === w.id ? T.accent : T.border}`, borderRadius: 12, padding: "18px 22px", transition: "border-color 0.2s" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: T.text, marginBottom: 3 }}>{w.name}</div>
                <div style={{ fontSize: 12, color: T.muted }}>{w.steps.length} steps</div>
              </div>
              <Btn onClick={() => run(w)} disabled={loading} style={{ padding: "7px 16px", fontSize: 12, opacity: loading && active?.id !== w.id ? 0.4 : 1 }}>
                {active?.id === w.id && loading ? "Running..." : "Run"}
              </Btn>
            </div>
            <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
              {w.steps.map((s, i) => (
                <div key={i} style={{ padding: "3px 9px", borderRadius: 5, fontSize: 11.5, background: active?.id === w.id && i <= stepIdx && loading ? T.accent : T.surface, color: active?.id === w.id && i <= stepIdx && loading ? "#fff" : T.muted, border: `1.5px solid ${active?.id === w.id && i <= stepIdx && loading ? T.accent : T.border}`, transition: "all 0.25s" }}>
                  {i + 1}. {s}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      {output && !loading && (
        <div style={{ background: T.surface, border: `1.5px solid ${T.border}`, borderRadius: 12, padding: 24 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: T.text, marginBottom: 12, textTransform: "uppercase", letterSpacing: "0.06em" }}>Output: {active?.name}</div>
          <pre style={{ color: T.text, fontSize: 13, lineHeight: 1.75, whiteSpace: "pre-wrap", fontFamily: "inherit", margin: 0 }}>{output}</pre>
        </div>
      )}
    </div>
  );
}

// ── Root ──────────────────────────────────────────────────────────────────────
export default function App() {
  // Try to load saved user on first render — never ask for key again
  const [user, setUser] = useState(() => loadUser());
  const [view, setView] = useState("projects");
  const [project, setProject] = useState(null);

  const handleAuth = (userData) => setUser(userData);
  const handleSignOut = () => { clearUser(); setUser(null); setView("projects"); setProject(null); };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap');
        * { box-sizing: border-box; }
        body { margin: 0; background: ${T.bg}; font-family: 'DM Sans', system-ui, sans-serif; color: ${T.text}; }
        @keyframes lp { 0%,100%{opacity:.2;transform:scale(.75)} 50%{opacity:1;transform:scale(1)} }
        ::-webkit-scrollbar{width:5px} ::-webkit-scrollbar-track{background:${T.surface}} ::-webkit-scrollbar-thumb{background:${T.border2};border-radius:3px}
        select option { background: #fff; color: ${T.text}; }
        textarea:focus { border-color: ${T.accent} !important; outline: none; }
        select:focus { border-color: ${T.accent} !important; outline: none; }
        input:focus { border-color: ${T.accent} !important; outline: none; }
      `}</style>

      {!user ? (
        <AuthPage onAuth={handleAuth} />
      ) : (
        <div style={{ display: "flex", minHeight: "100vh", background: T.bg }}>
          <Sidebar view={view} setView={setView} setProject={setProject} user={user} onSignOut={handleSignOut} />
          <main style={{ flex: 1, overflowY: "auto" }}>
            {view === "projects" && <ProjectsView setView={setView} setProject={setProject} />}
            {view === "chat" && <ChatView project={project} apiKey={user.apiKey} />}
            {view === "contracts" && <ContractsView apiKey={user.apiKey} />}
            {view === "workflows" && <WorkflowsView apiKey={user.apiKey} />}
          </main>
        </div>
      )}
    </>
  );
}
